package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    protected void onClickSettings(View view) {
      //  Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
    //    startActivity(intent);
    }
    public void aigamebutton(View view) {
      ////  String instanceName = "DESKTOP-0P5VR0E\\SQLEXPRESS";
     //   String db = "Cities";
      //  String username = "Admin";
      ////  String password = "Admin";
     //   String connectionUrl = "jdbc:sqlserver://%1$s;databaseName=%2$s;user=%3$s;password=%4$s;";
     ////   String connectionString = String.format(connectionUrl, instanceName, db, username, password);

        Intent intent = new Intent(this, AIGameActivity.class);
        startActivity(intent);
    }
    protected void onClick2(View view) {
        Intent intent = new Intent(MainActivity.this, CoopGameActivity.class);
        startActivity(intent);
    }

} 