package com.example.myapplication;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class AIGameActivity extends AppCompatActivity {
  //  String instanceName = "DESKTOP-0P5VR0E\\SQLEXPRESS";
 //   String db = "Cities";
  //  String username = "Dan";
   // String password = "gigant65";
   // String connectionUrl = "jdbc:sqlserver://%1$s;databaseName=%2$s;user=%3$s;password=%4$s;";
  //  String connectionString = String.format(connectionUrl, instanceName, db, username, password);
String currentCity;
    List<String> line0 = new LinkedList<String>();
    List<String> line1 = new LinkedList<String>();
    StringBuilder text = new StringBuilder();
    File cities = new File("raw/cities.txt");
    File usedCities = new File("raw/usedcities.txt");
    File Unedited = new File("raw/unedited.txt");
    String unedited = Unedited.toString();
    Scanner scan = new Scanner(System.in);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aigame);
        currentCity = "Москва";
        int points = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader(cities));

            while ((br.readLine()) != null) {
                line0.add(br.readLine());
            }
        }
        catch (IOException e) {
            //Ошибка
        }


    }
    public void nextturn(View view) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(usedCities));

            while ((br.readLine()) != null) {
                line1.add(br.readLine());
            }
            EditText editText;
            editText = (EditText) findViewById(R.id.incity);
            String incity = editText.getText().toString();
            StringBuilder text = new StringBuilder();
            String line;
                FileInputStream fileInputStream = new FileInputStream (cities);
                InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuilder = new StringBuilder();

                while ( (line = bufferedReader.readLine()) != null )
                {
                    stringBuilder.append(line + System.getProperty("line.separator"));
                }
                fileInputStream.close();
                line = stringBuilder.toString();

                bufferedReader.close();
            CharSequence incitysequence = (CharSequence) incity;
            if(line.contains(incitysequence) == false) {
                String outtext = ("Нет такого города!");
            }
            boolean v = false;
            List<String> Nline = new LinkedList<String>();
            Object[] mass0 =line0.toArray();
            for(int i = 0 ; i < line0.size();i++){
                String str = mass0[i].toString();
                if(str == incity){
                    v = true;
                    break;
                }
            }
            if(v == true) {
                String outtext = ("Город уже использован!");
            }
            else{
                try {
                    // отрываем поток для записи
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                            openFileOutput("raw/usedcities.txt", MODE_PRIVATE)));
                    // пишем данные
                    bw.write(incity);
                    // закрываем поток
                    bw.close();
                    // Log.d(LOG_TAG, "Файл записан");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }//записали входной
                int q = incity.length();
                char fl = incity.charAt(q);
String outcity;
                List<String> Lline = new LinkedList<String>();

               Object[] mass = line0.toArray();
for(int i = 0 ; i < line0.size();i++){
    String str = mass[i].toString();
if(str.charAt(str.charAt(0)) == fl){
    Lline.add(str);
}
}
                Object[] mass1 = Lline.toArray();
                int random_number1 = 0 + (int) (Math.random() * Lline.size());
outcity = (String) mass1[random_number1];
                CharSequence outsequence = (CharSequence) outcity;
                if(line1.contains(outsequence) == false) {
                    String outtext = outcity;
                    currentCity = outtext;
                }
                else{

                }
            }
          }
        catch (Exception ex)
        {
            Log.w("Exception error: ", ex.getMessage());
        }


    }

    protected void onStop(){
        super.onStop();
        FileOutputStream writer = null;
        try {
            writer = new FileOutputStream("raw/cities.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            writer.write(("").getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            // отрываем поток для записи
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                    openFileOutput("raw/cities.txt", MODE_PRIVATE)));
            // пишем данные

            bw.write(unedited);
            // закрываем поток
            bw.close();
            // Log.d(LOG_TAG, "Файл записан");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }//записали входной
    };


}
